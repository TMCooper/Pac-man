#ifndef GRILLE_H
#define GRILLE_H

#include "config.h"

// Fonction pour dessiner la grille
void dessinerGrille(int lignes, int colonnes, int tailleCellule);

#endif
