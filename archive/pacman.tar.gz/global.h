#ifndef GLOBAL_H
#define GLOBAL_H

#include <xamgraph.h>

// Déclaration de la référence de l'instance de XamGraph
extern XamGraph graph;

#endif // GLOBAL_H
