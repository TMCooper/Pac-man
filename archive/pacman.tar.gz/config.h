#ifndef CONFIG_H
#define CONFIG_H

// Définir la largeur de la grille
const int LARGEUR_GRILLE = 25;

// Définir la hauteur de la grille
const int HAUTEUR_GRILLE = 20;

// Définir la taille de chaque cellule de la grille
const int TAILLE_CELLULE = 30;

#endif // CONFIG_H
